# High Consulting AI - Custom n8n
This is the self-hosted automation system for High Consulting AI.
Includes a custom Dockerfile, logo, and stylesheet overrides.
